<!doctype html>
<html lang="en">
 <head>
  <title>Test TLS 1.2 version</title>
 </head>
 <body style="font-size:12px;">
<?php
/**
 * Test TLS 1.2 version
 * User: Eric
 * Date: 5/5/2017
 * Time: 4:58 PM
 */
$endpoint = '';
$available_enpoint = array(
    'howsmyssl'=>'https://www.howsmyssl.com/a/check',
    'paypal'=>'https://tlstest.paypal.com'
);
foreach ($available_enpoint as $key => $value) {
    if(isset($_GET['endpoint']) && $_GET['endpoint'] == $key) {
        $endpoint = $key;
        break;
    }
}

if(!empty($endpoint)) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $available_enpoint[$endpoint]);	
	//Force cURL to use TLS 1.2 if needed.	 
	curl_setopt($ch, CURLOPT_SSLVERSION, 6);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$response = curl_exec($ch);
	curl_close($ch);
	$tlsVer = array();
	$res = array();
	if($endpoint == 'paypal') {
		if($response == 'PayPal_Connection_OK') {
			$tls12 = array('tls_version'=>'TLS 1.2', 'enabled'=>true, 'message'=>'TLS 1.2 Support');			
		}
		else {
			$tls12 = array('enabled'=>false, 'message'=>'no TLS 1.2 Support');
		}
	}
	else {
		$tls12 = json_decode($response, true);
		if($tls12['tls_version']) {
			if(!isset($tls12['enabled'])) {
				$tls12['enabled'] = true;	
			}
			$tls12 = array('tls_version'=>$tls12['tls_version'], 'enabled'=>true, 'message'=>'TLS 1.2 Support');
		}
		else {
			$tls12 = array('enabled'=>false, 'message'=>'no TLS 1.2 Support');
		}
	}	
?>
<h3 class="hndle"><?php printf('Test Results Using %s.com Endpoint', $endpoint); ?></h3>
<div class="inside">
	<?php if($tls12['enabled']) { ?>
		<h2 style="color: green"><?php echo('TLS 1.2 Enabled');?></h2>
		<p><?php echo('Your site should work fine when making calls to gateways and APIs that require TLS 1.2. You may still want to consider the actions below to secure your site as much as possible.');?></p>
	<?php } else { ?>
		<h2 style="color: red"><?php echo('TLS 1.2 Not Enabled');?></h2>
		<p><?php echo('Your site is likely to fail when attempting calls to gateways and APIs that require TLS 1.2. Consider following the actions below to enable TLS 1.2.');?></p>
	<?php } ?>
<table class="wp-list-table widefat fixed" width="100%" cellpadding="0" cellspacing="0" border="0">
	<thead>
		<tr class="alternate">
			<th align="left" width="12%"><?php echo('Name'); ?></th>
			<th align="left" width="20%"><?php echo('Value'); ?></th>
			<th align="left"><?php echo('Action/Notes'); ?></th>
		</tr>
	</thead>
	<tbody>									
		<tr>
			<td><?php echo('Endpoint'); ?></td>
			<td><?php echo $available_enpoint[$endpoint]; ?></td>
			<td>
				<?php 
					if($tls12['enabled'])
						echo '<span style="color: green;">' . $tls12['message'] . '</span>';
					else
						echo '<strong style="color: red;">' . $tls12['message'] . '</strong>';
				?>
			</td>
		</tr>
		<tr class="alternate">
			<td><?php echo('PHP Version'); ?></td>
			<td><?php echo phpversion(); ?></td>
			<td>
				<?php 
					if(version_compare(phpversion(), '5.5.19', '>='))
						echo '<span style="color: green;">' . 'PHP version 5.5.19 or higher detected.' . '</span>';
					else
						echo '<strong style="color: red;">' . 'Upgrade to PHP version 5.5.19 or higher.' . '</strong>';
				?>
			</td>
		</tr>
		<tr>
			<td><?php echo('cURL Version'); ?></td>
			<td>
				<?php 
					if(!function_exists('curl_version'))
						echo '<span style="color: green;">' . 'cURL not installed.' . '</span>';
					else {
						$curl_version = curl_version();
						echo $curl_version['version'];
					}
				?>
			</td>
			<td>
				<?php 
					if(version_compare($curl_version['version'], '7.34.0', '>='))
						echo '<span style="color: green;">' . 'cURL version 7.34.0 or higher detected.' . '</span>';
					else
						echo '<strong style="color: red;">' . 'Upgrade to cURL version 7.34.0 or higher.' . '</strong>';
				?>
			</td>
		</tr>
		<tr class="alternate">
			<td><?php echo('cURL SSL Version'); ?></td>
			<td>
				<?php 
					if(!function_exists('curl_version'))
						echo('cURL not installed.');
					else {
						$curl_version = curl_version();
						echo $curl_version['ssl_version'];
					}
				?>
			</td>
			<td>
				<?php
					if(function_exists('curl_version')) {
						echo ('Make sure you are running OpenSSL/1.0.1 or higher, NSS/3.15.1 or higher, or the latest version of other cryptographic libraries.');
					}
					else
						echo('Install cURL if requests are not working or not secure.');
				?>
			</td>
		</tr>
									
	</tbody>
</table>
</div> <!-- end inside -->
<?php
}
else {
	foreach ($available_enpoint as $key => $value) {
		$endpoint = $key;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $available_enpoint[$endpoint]);
		curl_setopt($ch, CURLOPT_SSLVERSION, 6);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$response = curl_exec($ch);
		curl_close($ch);
		$tlsVer = array();
		$res = array();
		if($endpoint == 'paypal') {
			if($response == 'PayPal_Connection_OK') {
				$tls12 = array('tls_version'=>'TLS 1.2', 'enabled'=>true, 'message'=>'TLS 1.2 Support');			
			}
			else {
				$tls12 = array('enabled'=>false, 'message'=>'no TLS 1.2 Support');
			}
		}
		else {
			$tls12 = json_decode($response, true);
			if($tls12['tls_version']) {
				if(!isset($tls12['enabled'])) {
					$tls12['enabled'] = true;	
				}
				$tls12 = array('tls_version'=>$tls12['tls_version'], 'enabled'=>true, 'message'=>'TLS 1.2 Support');
			}
			else {
				$tls12 = array('enabled'=>false, 'message'=>'no TLS 1.2 Support');
			}
		}
?>
<h3 class="hndle"><?php printf('Test Results Using %s.com Endpoint', $endpoint); ?></h3>
<div class="inside">
	<?php if($tls12['enabled']) { ?>
		<h2 style="color: green"><?php echo('TLS 1.2 Enabled');?></h2>
		<p><?php echo('Your site should work fine when making calls to gateways and APIs that require TLS 1.2. You may still want to consider the actions below to secure your site as much as possible.');?></p>
	<?php } else { ?>
		<h2 style="color: red"><?php echo('TLS 1.2 Not Enabled');?></h2>
		<p><?php echo('Your site is likely to fail when attempting calls to gateways and APIs that require TLS 1.2. Consider following the actions below to enable TLS 1.2.');?></p>
	<?php } ?>
<table class="wp-list-table widefat fixed" width="100%" cellpadding="0" cellspacing="0" border="0">
	<thead>
		<tr class="alternate">
			<th align="left" width="12%"><?php echo('Name'); ?></th>
			<th align="left" width="20%"><?php echo('Value'); ?></th>
			<th align="left"><?php echo('Action/Notes'); ?></th>
		</tr>
	</thead>
	<tbody>									
		<tr>
			<td><?php echo('Endpoint'); ?></td>
			<td><?php echo $available_enpoint[$endpoint]; ?></td>
			<td>
				<?php 
					if($tls12['enabled'])
						echo '<span style="color: green;">' . $tls12['message'] . '</span>';
					else
						echo '<strong style="color: red;">' . $tls12['message'] . '</strong>';
				?>
			</td>
		</tr>
		<tr class="alternate">
			<td><?php echo('PHP Version'); ?></td>
			<td><?php echo phpversion(); ?></td>
			<td>
				<?php 
					if(version_compare(phpversion(), '5.5.19', '>='))
						echo '<span style="color: green;">' . 'PHP version 5.5.19 or higher detected.' . '</span>';
					else
						echo '<strong style="color: red;">' . 'Upgrade to PHP version 5.5.19 or higher.' . '</strong>';
				?>
			</td>
		</tr>
		<tr>
			<td><?php echo('cURL Version'); ?></td>
			<td>
				<?php 
					if(!function_exists('curl_version'))
						echo '<span style="color: green;">' . 'cURL not installed.' . '</span>';
					else {
						$curl_version = curl_version();
						echo $curl_version['version'];
					}
				?>
			</td>
			<td>
				<?php 
					if(version_compare($curl_version['version'], '7.34.0', '>='))
						echo '<span style="color: green;">' . 'cURL version 7.34.0 or higher detected.' . '</span>';
					else
						echo '<strong style="color: red;">' . 'Upgrade to cURL version 7.34.0 or higher.' . '</strong>';
				?>
			</td>
		</tr>
		<tr class="alternate">
			<td><?php echo('cURL SSL Version'); ?></td>
			<td>
				<?php 
					if(!function_exists('curl_version'))
						echo('cURL not installed.');
					else {
						$curl_version = curl_version();
						echo $curl_version['ssl_version'];
					}
				?>
			</td>
			<td>
				<?php
					if(function_exists('curl_version')) {
						echo ('Make sure you are running OpenSSL/1.0.1 or higher, NSS/3.15.1 or higher, or the latest version of other cryptographic libraries.');
					}
					else
						echo('Install cURL if requests are not working or not secure.');
				?>
			</td>
		</tr>									
	</tbody>
</table>
</div> <!-- end inside -->
<?php
	}
}
?>
<h2>Below is a sandbox authorize.net transaction</h2>
<p>Endpoint: https://test.authorize.net/gateway/transact.dll</p>
<?php
//send a test transaction to authorize.net sandbox
$login = '3YJ72rpEbns';  // you'll get this value from authorize.net
$tran_key = '2883uVWf3Ga76aMm';  // you'll get this value from authorize.net
$delimiter = '|';  // the delimiter we want the response to use
 
$authnet_values	= array(
	"x_login"			=> $login,
	"x_version"			=> "3.1",  // or whatever version you're using
	"x_delim_char"			=> $delimiter,
	"x_delim_data"			=> "TRUE",
	"x_type"			=> "AUTH_CAPTURE",
	"x_method"			=> "CC",
	"x_tran_key"			=> $tran_key,
	"x_relay_response"		=> "FALSE",
	"x_card_num"			=> '4111111111111111',
	"x_exp_date"			=> '1222',
	"x_description"			=> 'Test Transaction',
	"x_amount"			=> 1.7,
	"x_first_name"			=> 'Forix',
	"x_last_name"			=> 'Test',
	"x_address"			=> '2140 SW Jefferson Street',
	"x_city"			=> 'Portland',
	"x_state"			=> 'OR',
	"x_zip"				=> '97201'
);
 
$fields = http_build_query($authnet_values); 
$curl_request = curl_init("https://test.authorize.net/gateway/transact.dll"); 
curl_setopt($curl_request, CURLOPT_HEADER, 0);
curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl_request, CURLOPT_POSTFIELDS, $fields);
$curl_response = curl_exec($curl_request);
curl_close($curl_request);

$response_values = explode($delimiter, $curl_response);
if(isset($response_values[3])) {	
	echo 'Message: <span style="color:red;">'. $response_values[3] . '</span>';
}
else {
	print_r($response_values);
}
unset($authnet_values['x_login']);unset($authnet_values['x_tran_key']);
echo '<pre>'; print_r($authnet_values); echo '</pre>'; 
echo '<pre>'; print_r($response_values); echo '</pre>'; 
?>
</body>
</html>